const logger = require('../logger');
const config = require('../config');
const modHelper = require('../modHelper');
const embedBuilder = require('../embedBuilder');
const fs = require('fs');
const express = require('express');
const app = express();
const port = 3000;

// Require Eris for synthax highlight
// eslint-disable-next-line no-unused-vars
const Eris = require('eris');
const uuid = require('uuid');

module.exports._mod_info = {
    name: 'code_commands',
    description: 'Q&A plugin for Signals Everywhere',
    author: 'Ryzerth',
    version: '1.0.0'
};

let questions = {};

function addQuestion(question, author, pic) {
    let id = uuid();
    questions[id] = {
        id: id,
        question: question,
        username: author,
        avatar: pic
    };
}

function delQuestion(id) {
    delete questions[id];
}

module.exports._mod_init = (bot) => {
    logger.log(`Initializing code_commands...`);
    app.use(express.static('qna_www'));
    app.get('/questions', async (req, res) => {
        res.send(JSON.stringify(questions));
    });
    app.get('/del_question', async (req, res) => {
        delQuestion(req.query.id);
        res.send('ok');
    });
    app.listen(port);
    logger.ok();
};

module.exports._mod_end = (bot) => {
    logger.log(`Stopping code_commands...`);
    logger.ok();
};

module.exports.ask = {
    name: 'ask',
    usage: 'ask [question]',
    description: 'Ask a question',
    adminOnly: false,
    ownerOnly: false,
    /**
     * @param {Eris.Client} bot Text channel
     * @param {Eris.Message} message Discord message
     * @param {Eris.Message} text Text after the command
     * @param {string[]} args Discord message
     */
    baseCmd: async (bot, message, text, args) => {
        if (args.length == 0) {
            modHelper.modules['misc_commands']._help(message.channel, module.exports.ask);
        }
        addQuestion(text, `${message.author.username}#${message.author.discriminator}`, message.author.avatarURL);
    },
};