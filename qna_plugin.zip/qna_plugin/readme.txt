To install:

1) Stop the bot
2) Copy the qna_www directory to the root of the bot
3) Copy qna.js to the modules/ directory
4) Start the bot